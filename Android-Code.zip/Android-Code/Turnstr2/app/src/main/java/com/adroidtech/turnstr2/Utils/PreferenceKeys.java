package com.adroidtech.turnstr2.Utils;

/**
 * Created by sarbjot.singh on 9/22/2016.
 */
public class PreferenceKeys {
    public static final String IS_REMIMBER = "loged_in";
    public static final String SAVED_USERNAME = "saved_username";
    public static final String SAVED_PASSWORD = "saved_password";
    public static final String IS_LOGIN = "loged_in";
    public static final String USER_DETAIL = "user_detail";
    public static final String APP_AUTH_TOKEN = "auth_token";

    public static final String FIREBASE_TOKEN = "firebase_token";


}
