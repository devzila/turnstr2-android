package com.adroidtech.turnstr2.chat.models;

/**
 * Created by narinder on 18/12/17.
 */

public class Friends {

}
