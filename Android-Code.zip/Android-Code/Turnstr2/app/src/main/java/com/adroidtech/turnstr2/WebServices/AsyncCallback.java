package com.adroidtech.turnstr2.WebServices;

public interface AsyncCallback {

    public void getAsyncResult(String jsonObject, String txt);
}
