package com.adroidtech.turnstr2.Utils;

/**
 * Created by sarbjot.singh on 3/9/2017.
 */

public class Constants {
    public static final String USER_ID = "user_id";

}
