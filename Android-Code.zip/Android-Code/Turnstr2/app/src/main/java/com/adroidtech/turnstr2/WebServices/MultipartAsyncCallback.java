package com.adroidtech.turnstr2.WebServices;

import org.json.JSONObject;

public interface MultipartAsyncCallback {

    public void getMultipartAsyncResult(JSONObject jsonObject, String txt);
}
